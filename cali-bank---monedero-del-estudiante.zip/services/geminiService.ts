
import { GoogleGenAI, Type } from "@google/genai";
import { Student, Transaction } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getStudentFeedback(student: Student): Promise<string> {
  const history = student.transactions.slice(-5).map(t => 
    `${t.type === 'CREDIT' ? 'Ganó' : 'Perdió'} ${t.amount} puntos por ${t.concept}`
  ).join(', ');

  const prompt = `
    Como un profesor motivador y empoderador, analiza el historial reciente de este estudiante y genera un mensaje corto de aliento (máximo 2 párrafos).
    Nombre: ${student.name}
    Saldo actual (Calificación): ${student.balance}
    Historial reciente: ${history || 'Sin movimientos aún.'}
    
    Si el saldo es alto, felicítalo. Si ha bajado, anímalo a mejorar con consejos prácticos. Usa un lenguaje amable y moderno.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "¡Sigue esforzándote! Cada punto cuenta para tu futuro.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "¡Vas por buen camino! Sigue trabajando duro en clase.";
  }
}
