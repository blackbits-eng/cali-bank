
import React, { useState, useEffect } from 'react';
import { Student } from '../types';
import { QRGenerator } from './QRGenerator';
import { TransactionItem } from './TransactionItem';
import { Sparkles, ArrowLeft, UserCircle, ScanLine, CalendarCheck, CheckCircle2, Landmark, Info, AlertTriangle, X, ArrowUpCircle, RefreshCw } from 'lucide-react';
import { getStudentFeedback } from '../services/geminiService';
import { playSuccessSound } from '../services/audioService';
import { QRScanner } from './QRScanner';

interface StudentDashboardProps {
  students: Student[];
  currentUnit: number;
  currentStudentId: string | null;
  setCurrentStudentId: (id: string | null) => void;
  registerAttendance: (studentId: string) => void;
  requestLoan: (studentId: string, amount: number) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ 
  students, 
  currentUnit,
  currentStudentId, 
  setCurrentStudentId,
  registerAttendance,
  requestLoan
}) => {
  const [inputId, setInputId] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [loadingFeedback, setLoadingFeedback] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);
  const [showLoginScanner, setShowLoginScanner] = useState(false);
  const [showLoanPanel, setShowLoanPanel] = useState(false);

  const currentStudent = students.find(s => s.id === currentStudentId);

  const isAttendanceRegisteredToday = () => {
    if (!currentStudent?.lastAttendance) return false;
    const now = new Date();
    const last = new Date(currentStudent.lastAttendance);
    return now.toDateString() === last.toDateString();
  };

  useEffect(() => {
    if (currentStudent && !feedback) fetchFeedback();
  }, [currentStudent]);

  const handleLogin = (idOrName: string) => {
    const found = students.find(s => s.id === idOrName || s.name.toLowerCase() === idOrName.toLowerCase());
    if (found) {
      setCurrentStudentId(found.id);
      playSuccessSound();
      setShowLoginScanner(false);
    } else {
      if (!showLoginScanner) alert("Alumno no encontrado.");
    }
  };

  const fetchFeedback = async () => {
    if (!currentStudent) return;
    setLoadingFeedback(true);
    const msg = await getStudentFeedback(currentStudent);
    setFeedback(msg);
    setLoadingFeedback(false);
  };

  const handleRequestLoanAction = () => {
    if (currentStudent) {
      const meta = currentUnit * 1000;
      if (confirm(`¿Solicitar préstamo de 500 Calis?\n\nTérminos:\n1. Debes llegar a ${meta} antes del cierre de unidad.\n2. Si llegas, es gratis.\n3. Si no, pagas el doble.`)) {
        requestLoan(currentStudent.id, 500);
        setShowLoanPanel(false);
      }
    }
  };

  if (!currentStudent) {
    return (
      <div className="max-w-md mx-auto mt-12 animate-in fade-in duration-500">
        {showLoginScanner && <QRScanner onScan={handleLogin} onClose={() => setShowLoginScanner(false)} />}
        <div className="bg-slate-900 p-8 rounded-[3rem] shadow-xl border border-white/10 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-amber-500 to-indigo-500"></div>
          <div className="w-20 h-20 bg-indigo-500/10 text-indigo-400 rounded-3xl flex items-center justify-center mx-auto mb-8 border border-indigo-500/20"><UserCircle size={40} /></div>
          <h2 className="text-3xl font-black mb-8 uppercase tracking-tighter">Mi Monedero</h2>
          <div className="space-y-3">
            <button onClick={() => setShowLoginScanner(true)} className="w-full bg-indigo-600 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-2 text-sm uppercase tracking-widest"><ScanLine size={20} /> Escanear QR</button>
            <form onSubmit={(e) => { e.preventDefault(); handleLogin(inputId); }} className="space-y-4">
              <input type="text" placeholder="NOMBRE O ID" value={inputId} onChange={e => setInputId(e.target.value)} className="w-full bg-slate-950 border border-white/5 rounded-2xl px-5 py-4 text-white text-lg text-center font-bold outline-none focus:border-amber-500 uppercase" />
              <button type="submit" className="w-full bg-white/5 text-white font-black py-4 rounded-2xl text-xs uppercase tracking-widest border border-white/5">Acceder Manual</button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  const registeredToday = isAttendanceRegisteredToday();
  const hasLoan = currentStudent.activeLoan?.isActive;

  return (
    <div className="max-w-4xl mx-auto pb-10 animate-in fade-in duration-300">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-8">
        <button onClick={() => { setCurrentStudentId(null); setFeedback(null); }} className="text-slate-500 hover:text-white font-black uppercase text-[10px] tracking-widest flex items-center gap-2 transition-colors"><ArrowLeft size={16} /> Salir de Sesión</button>
        <div className="flex gap-2 w-full md:w-auto">
          <button onClick={() => setShowLoanPanel(true)} className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 border rounded-xl font-black text-[9px] uppercase tracking-widest transition-all ${hasLoan ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' : 'bg-indigo-600/10 text-indigo-400 border-indigo-400/20'}`}>
            <Landmark size={14} /> {hasLoan ? 'Crédito Activo' : 'Cali-Crédito'}
          </button>
          <button onClick={() => registerAttendance(currentStudent.id)} disabled={registeredToday} className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-black text-[9px] uppercase tracking-widest transition-all ${registeredToday ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 'bg-amber-500 text-slate-950 hover:bg-amber-400'}`}>
            {registeredToday ? <CheckCircle2 size={14} /> : <CalendarCheck size={14} />}
            {registeredToday ? 'Listo' : 'Asistencia (+1 Ȼ)'}
          </button>
        </div>
      </div>

      <div className="bg-gradient-to-br from-indigo-800 to-indigo-950 rounded-[3rem] p-8 md:p-10 text-white shadow-2xl relative overflow-hidden mb-8 border border-white/10">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-center md:text-left flex-1">
            <p className="text-indigo-200 text-[9px] font-black uppercase tracking-[0.4em] mb-4">Saldo Cali-Bank</p>
            <div className="flex items-baseline gap-2 justify-center md:justify-start">
              <h1 className="text-8xl font-black tracking-tighter leading-none">{currentStudent.balance}</h1>
              <span className="text-amber-500 text-3xl font-black">Ȼ</span>
            </div>
            <div className="mt-8 inline-flex items-center gap-3 bg-black/40 px-5 py-3 rounded-2xl border border-white/5">
              <img src={currentStudent.avatar} className="w-10 h-10 rounded-xl bg-indigo-500/20" />
              <div>
                <p className="text-sm font-black uppercase leading-tight">{currentStudent.name}</p>
                <p className="text-[8px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">Unidad {currentUnit}</p>
              </div>
            </div>
          </div>
          <div className="bg-white p-4 rounded-[2.5rem] shadow-xl cursor-pointer hover:scale-105 transition-transform" onClick={() => setShowQRModal(true)}>
             <QRGenerator value={`${window.location.origin}${window.location.pathname}?sid=${currentStudent.id}`} size={120} />
             <p className="text-[7px] text-slate-400 font-black uppercase mt-3 text-center tracking-widest">Mi Pase Digital</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-white/5 rounded-[2.5rem] p-8 shadow-xl">
          <div className="flex items-center gap-3 mb-6"><Sparkles size={18} className="text-indigo-400" /><h3 className="text-sm font-black uppercase tracking-widest">Reporte Maestro IA</h3></div>
          {loadingFeedback ? (
            <div className="py-10 flex justify-center"><RefreshCw size={24} className="text-amber-500 animate-spin" /></div>
          ) : (
            <p className="text-slate-300 italic text-sm font-medium leading-relaxed">"{feedback}"</p>
          )}
        </div>
        <div className="bg-slate-900 border border-white/5 rounded-[2.5rem] p-8 shadow-xl">
          <h3 className="text-sm font-black mb-6 uppercase tracking-widest">Historial</h3>
          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1 custom-scrollbar">
            {currentStudent.transactions.map(tx => <TransactionItem key={tx.id} transaction={tx} />)}
          </div>
        </div>
      </div>

      {showLoanPanel && (
        <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-md z-[100] flex items-center justify-center p-6 animate-in fade-in">
          <div className="bg-slate-900 border border-white/10 p-10 rounded-[3rem] max-w-sm w-full shadow-2xl relative">
            <button onClick={() => setShowLoanPanel(false)} className="absolute top-6 right-6 text-slate-500"><X size={24} /></button>
            <div className="text-center">
              <Landmark size={40} className="text-indigo-400 mx-auto mb-6" />
              <h2 className="text-2xl font-black mb-2 uppercase">Cali-Crédito</h2>
              <p className="text-slate-500 text-[10px] uppercase tracking-widest mb-8">Unidad {currentUnit}</p>
              <div className="bg-white/5 p-6 rounded-2xl text-left text-xs text-slate-300 space-y-4 mb-8">
                 <p>• Recibe <b>500 Ȼ</b> al instante.</p>
                 <p>• Meta de condonación: <b>{currentUnit * 1000} Ȼ</b>.</p>
                 <p>• Si no llegas, pagas <b>1000 Ȼ</b> al cierre.</p>
              </div>
              <button onClick={handleRequestLoanAction} disabled={hasLoan} className="w-full bg-indigo-600 text-white font-black py-4 rounded-2xl text-xs uppercase tracking-widest shadow-lg active:scale-95 disabled:opacity-30">
                {hasLoan ? 'Ya tienes un préstamo' : 'Solicitar Préstamo'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showQRModal && (
        <div className="fixed inset-0 bg-slate-950/90 z-[100] flex items-center justify-center p-6 animate-in zoom-in" onClick={() => setShowQRModal(false)}>
          <div className="bg-slate-900 rounded-[3.5rem] p-10 max-w-sm w-full text-center border border-white/10 shadow-2xl">
            <div className="bg-white p-5 rounded-[2rem] inline-block mb-8"><QRGenerator value={`${window.location.origin}${window.location.pathname}?sid=${currentStudent.id}`} size={180} /></div>
            <p className="text-white font-black text-xl mb-6 uppercase">{currentStudent.name}</p>
            <button onClick={() => setShowQRModal(false)} className="w-full bg-white text-slate-950 font-black py-4 rounded-2xl text-xs uppercase tracking-widest">Cerrar Pase</button>
          </div>
        </div>
      )}
    </div>
  );
};
