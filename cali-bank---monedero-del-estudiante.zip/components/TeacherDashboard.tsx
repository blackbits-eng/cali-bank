
import React, { useState } from 'react';
import { Student, TransactionType } from '../types';
import { 
  UserPlus, Search, PlusCircle, MinusCircle, Users, 
  PenTool, ScanLine, Zap, Star, BookOpen, 
  Heart, AlertCircle, Ban, Database, Trash2, 
  ArrowRightCircle, Settings, Copy, ClipboardPaste, Link, CheckCircle2
} from 'lucide-react';
import { QRScanner } from './QRScanner';
import { playCoinSound, playErrorSound, playSuccessSound } from '../services/audioService';

interface TeacherDashboardProps {
  students: Student[];
  currentUnit: number;
  addStudent: (name: string) => void;
  deleteStudent: (id: string) => void;
  updateBalance: (id: string, amount: number, concept: string, type: TransactionType) => void;
  requestLoan: (studentId: string, amount: number) => void;
  processEndOfUnit: () => void;
  generateSyncLink: () => void;
  copyRawDb: () => void;
  importRawDb: (text: string) => boolean;
  setAllStudents: (students: Student[]) => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ 
  students, 
  currentUnit,
  addStudent, 
  deleteStudent,
  updateBalance,
  processEndOfUnit,
  generateSyncLink,
  copyRawDb,
  importRawDb
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [newName, setNewName] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [customAmount, setCustomAmount] = useState<number>(10);
  const [customConcept, setCustomConcept] = useState('');
  const [showAdminTools, setShowAdminTools] = useState(false);
  const [importText, setImportText] = useState('');

  const filteredStudents = students.filter(s => s.name.toLowerCase().includes(searchTerm.toLowerCase()));
  const selectedStudent = students.find(s => s.id === selectedStudentId);

  const handleTransaction = (type: TransactionType, amount?: number, concept?: string) => {
    const finalAmount = amount || customAmount;
    const finalConcept = concept || customConcept;
    if (selectedStudentId && finalAmount > 0 && finalConcept) {
      updateBalance(selectedStudentId, finalAmount, finalConcept, type);
      if (type === 'CREDIT') playCoinSound();
      else playErrorSound();
      if (!amount) setCustomConcept('');
    }
  };

  const quickActions = [
    { label: 'Participación', amount: 5, concept: 'Excelente participación', type: 'CREDIT' as TransactionType, icon: <Star size={16} />, color: 'bg-emerald-500 text-slate-950' },
    { label: 'Buen Trabajo', amount: 15, concept: 'Trabajo destacado', type: 'CREDIT' as TransactionType, icon: <Zap size={16} />, color: 'bg-amber-500 text-slate-950' },
    { label: 'Tarea Completa', amount: 10, concept: 'Tarea a tiempo', type: 'CREDIT' as TransactionType, icon: <BookOpen size={16} />, color: 'bg-indigo-500 text-white' },
    { label: 'Falta Tarea', amount: 10, concept: 'Incumplimiento', type: 'DEBIT' as TransactionType, icon: <Ban size={16} />, color: 'bg-rose-500 text-white' },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {showScanner && <QRScanner onScan={(id) => { setSelectedStudentId(id); setShowScanner(false); playSuccessSound(); }} onClose={() => setShowScanner(false)} />}
      
      <div className="lg:col-span-4 space-y-4">
        {/* Administración de Sincronización */}
        <div className="bg-slate-900 border border-white/5 rounded-[2rem] p-5 shadow-xl">
          <div className="flex justify-between items-center mb-4">
            <p className="text-indigo-400 text-[9px] font-black uppercase tracking-widest">Sincronización</p>
            <button onClick={() => setShowAdminTools(!showAdminTools)} className="text-slate-500 hover:text-white"><Settings size={18} /></button>
          </div>
          
          {!showAdminTools ? (
            <div className="space-y-3">
              <h3 className="text-2xl font-black uppercase tracking-tighter">UNIDAD {currentUnit}</h3>
              <button onClick={generateSyncLink} className="w-full bg-indigo-600/20 text-indigo-400 border border-indigo-500/20 font-black py-3 rounded-xl hover:bg-indigo-600 hover:text-white transition-all flex items-center justify-center gap-2 text-[10px] uppercase tracking-widest">
                <Link size={14} /> Crear Link de Clonación
              </button>
              <button onClick={processEndOfUnit} className="w-full bg-white text-slate-950 font-black py-3 rounded-xl hover:bg-slate-200 transition-all text-[10px] uppercase tracking-widest">
                Finalizar Unidad
              </button>
            </div>
          ) : (
            <div className="space-y-3 animate-in fade-in">
              <button onClick={copyRawDb} className="w-full bg-slate-800 text-white py-2 rounded-lg text-[9px] uppercase font-black flex items-center justify-center gap-2"><Copy size={12} /> Copiar Código DB</button>
              <textarea placeholder="Pega código aquí..." value={importText} onChange={e => setImportText(e.target.value)} className="w-full h-16 bg-black border border-white/10 rounded-lg p-2 text-[10px] text-indigo-400 font-mono" />
              <button onClick={() => importRawDb(importText)} className="w-full bg-emerald-600 text-white py-2 rounded-lg text-[9px] uppercase font-black flex items-center justify-center gap-2"><ClipboardPaste size={12} /> Pegar y Sincronizar</button>
            </div>
          )}
        </div>

        <div className="bg-slate-900 border border-white/5 rounded-[2rem] p-5 shadow-xl flex flex-col h-[500px]">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-black flex items-center gap-2 uppercase"><Users className="text-indigo-400" size={16} /> Alumnos</h3>
            <div className="flex gap-2">
              <button onClick={() => setShowScanner(true)} className="p-2 bg-amber-500 text-slate-950 rounded-lg"><ScanLine size={14} /></button>
              <button onClick={() => setShowAddForm(!showAddForm)} className="p-2 bg-white/10 text-white rounded-lg"><UserPlus size={14} /></button>
            </div>
          </div>
          
          <input type="text" placeholder="BUSCAR..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full bg-black border border-white/5 rounded-xl px-4 py-2 text-[10px] text-white outline-none mb-4 uppercase" />
          
          <div className="space-y-1 overflow-y-auto pr-1 flex-1 custom-scrollbar">
            {filteredStudents.map(student => (
              <button key={student.id} onClick={() => setSelectedStudentId(student.id)} className={`w-full flex items-center justify-between p-2.5 rounded-xl transition-all ${selectedStudentId === student.id ? 'bg-indigo-600' : 'bg-white/5 hover:bg-white/10'}`}>
                <div className="flex items-center gap-2 truncate">
                  <img src={student.avatar} className="w-6 h-6 rounded-md bg-slate-800" />
                  <span className="font-bold text-[9px] uppercase truncate">{student.name}</span>
                </div>
                <span className="font-black text-[9px] text-amber-500">{student.balance} Ȼ</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="lg:col-span-8 space-y-4">
        {selectedStudent ? (
          <div className="animate-in fade-in duration-300">
            <div className="bg-slate-900 border border-white/5 rounded-[2.5rem] p-6 shadow-xl flex items-center gap-6 mb-6">
              <img src={selectedStudent.avatar} className="w-24 h-24 rounded-2xl bg-slate-800 border-2 border-white/10" />
              <div className="flex-1">
                <h2 className="text-2xl font-black uppercase tracking-tighter leading-none mb-2">{selectedStudent.name}</h2>
                <p className="text-[9px] text-slate-500 font-mono">ID: {selectedStudent.id}</p>
                <div className="mt-4 inline-block bg-amber-500/10 text-amber-500 px-4 py-2 rounded-xl border border-amber-500/20">
                   <span className="text-2xl font-black">{selectedStudent.balance}</span>
                   <span className="text-xs font-black ml-1 uppercase tracking-widest">Calis</span>
                </div>
              </div>
              <button onClick={() => deleteStudent(selectedStudent.id)} className="p-2 text-rose-500 hover:bg-rose-500/10 rounded-full transition-all"><Trash2 size={20} /></button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-900 border border-white/5 rounded-[2rem] p-6">
                <h4 className="text-xs font-black mb-4 uppercase text-indigo-400">Acciones</h4>
                <div className="grid grid-cols-2 gap-2">
                  {quickActions.map((action, idx) => (
                    <button key={idx} onClick={() => handleTransaction(action.type, action.amount, action.label)} className={`flex flex-col items-center justify-center p-3 rounded-2xl transition-all hover:scale-[1.03] border border-transparent ${action.color}`}>
                      {action.icon}
                      <span className="text-[8px] font-black uppercase mt-1 leading-none">{action.label}</span>
                      <span className="text-[7px] opacity-70">{action.type === 'CREDIT' ? '+' : '-'}{action.amount}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="bg-slate-900 border border-white/5 rounded-[2rem] p-6">
                <h4 className="text-xs font-black mb-4 uppercase text-indigo-400">Manual</h4>
                <input type="text" placeholder="CONCEPTO..." value={customConcept} onChange={e => setCustomConcept(e.target.value)} className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-[10px] text-white mb-2 uppercase font-bold" />
                <div className="flex gap-2">
                  <input type="number" value={customAmount} onChange={e => setCustomAmount(Number(e.target.value))} className="w-16 bg-black border border-white/10 rounded-xl text-center text-xs font-black" />
                  <button onClick={() => handleTransaction('CREDIT')} className="flex-1 bg-emerald-500 text-slate-950 rounded-xl font-black text-[10px] uppercase"><PlusCircle size={14} className="mx-auto" /></button>
                  <button onClick={() => handleTransaction('DEBIT')} className="flex-1 bg-rose-500 text-white rounded-xl font-black text-[10px] uppercase"><MinusCircle size={14} className="mx-auto" /></button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="h-full min-h-[400px] flex flex-col items-center justify-center bg-slate-900 border-2 border-dashed border-white/5 rounded-[3rem] text-slate-500 p-10 text-center">
            <Database size={48} className="opacity-10 mb-4" />
            <p className="text-[10px] font-black uppercase tracking-[0.3em]">Selecciona un registro escolar</p>
          </div>
        )}
      </div>
    </div>
  );
};
